const express = require('express');
const http = require('http');
const socketio = require('socket.io');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketio(server, {
  cors: { origin: '*' }
});

app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true, useUnifiedTopology: true
});

const UserSchema = new mongoose.Schema({
  email: { type: String, unique: true },
  password: String,
  balance: { type: Number, default: 1000 }
});

const BetSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  round: Number,
  amount: Number,
  cashOutMultiplier: Number,
  winAmount: Number,
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', UserSchema);
const Bet = mongoose.model('Bet', BetSchema);

function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).send({ message: 'No token' });
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).send({ message: 'Invalid token' });
    req.user = user;
    next();
  });
}

// Auth routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password } = req.body;
    const hash = await bcrypt.hash(password, 10);
    const user = new User({ email, password: hash });
    await user.save();
    const token = jwt.sign({ id: user._id, email: user.email }, process.env.JWT_SECRET);
    res.json({ token });
  } catch {
    res.status(400).send({ message: 'User already exists or invalid data' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).send({ message: 'Invalid credentials' });
  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(400).send({ message: 'Invalid credentials' });
  const token = jwt.sign({ id: user._id, email: user.email }, process.env.JWT_SECRET);
  res.json({ token });
});

// Wallet routes
app.post('/api/wallet/deposit', authMiddleware, async (req, res) => {
  const { amount } = req.body;
  if (amount <= 0) return res.status(400).send({ message: 'Invalid amount' });
  const user = await User.findById(req.user.id);
  user.balance += amount;
  await user.save();
  res.json({ balance: user.balance });
});

app.post('/api/wallet/withdraw', authMiddleware, async (req, res) => {
  const { amount } = req.body;
  if (amount <= 0) return res.status(400).send({ message: 'Invalid amount' });
  const user = await User.findById(req.user.id);
  if (user.balance < amount) return res.status(400).send({ message: 'Insufficient balance' });
  user.balance -= amount;
  await user.save();
  res.json({ balance: user.balance });
});

app.get('/api/bets/history', authMiddleware, async (req, res) => {
  const bets = await Bet.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(10);
  res.json({ bets });
});

// Crash game logic
let currentRound = 1;
let roundInterval;
let bets = []; // {userId, amount, cashedOut: false, cashOutMultiplier: null, winAmount: 0}
let crashMultiplier = 0;
let gameState = 'betting'; // betting, running, ended

async function startRound() {
  bets = [];
  crashMultiplier = 0;
  gameState = 'betting';
  io.emit('round:start', { round: currentRound });
  await new Promise(r => setTimeout(r, 10000)); // 10 sec betting

  gameState = 'running';
  io.emit('round:running', { round: currentRound });
  let intervalCount = 0;

  while (crashMultiplier < 10 && Math.random() > 0.01 && intervalCount < 200) {
    await new Promise(r => setTimeout(r, 100));
    crashMultiplier = Number((crashMultiplier + 0.1).toFixed(2));
    io.emit('crash:update', { multiplier: crashMultiplier });
    intervalCount++;
  }

  // End round
  gameState = 'ended';
  io.emit('round:end', { round: currentRound, crashMultiplier });

  // Calculate winnings and update balances
  for (const bet of bets) {
    let winAmount = 0;
    if (bet.cashedOut && bet.cashOutMultiplier <= crashMultiplier) {
      winAmount = bet.amount * bet.cashOutMultiplier;
    }
    bet.winAmount = winAmount;

    if (winAmount > 0) {
      const user = await User.findById(bet.userId);
      user.balance += winAmount;
      await user.save();
    }

    const betRecord = new Bet({
      userId: bet.userId,
      round: currentRound,
      amount: bet.amount,
      cashOutMultiplier: bet.cashOutMultiplier,
      winAmount: bet.winAmount,
    });
    await betRecord.save();
  }

  currentRound++;
  setTimeout(startRound, 5000); // 5 sec delay between rounds
}

io.use(async (socket, next) => {
  const token = socket.handshake.auth.token;
  if (!token) return next(new Error('No token'));
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return next(new Error('Invalid token'));
    socket.user = user;
    next();
  });
});

io.on('connection', async socket => {
  const user = await User.findById(socket.user.id);
  socket.emit('balance:update', { balance: user.balance });
  socket.emit('round:start', { round: currentRound });

  socket.on('bet:place', async ({ amount }) => {
    if (gameState !== 'betting') {
      socket.emit('bet:error', 'Betting closed');
      return;
    }
    if (amount <= 0 || amount > user.balance) {
      socket.emit('bet:error', 'Invalid bet amount');
      return;
    }
    user.balance -= amount;
    await user.save();

    bets.push({ userId: user._id, amount, cashedOut: false, cashOutMultiplier: null, winAmount: 0 });
    socket.emit('balance:update', { balance: user.balance });
    socket.emit('bet:confirmed', { amount });
  });

  socket.on('bet:cashout', () => {
    if (gameState !== 'running') {
      socket.emit('bet:error', 'Cannot cash out now');
      return;
    }
    const bet = bets.find(b => b.userId.toString() === user._id.toString() && !b.cashedOut);
    if (!bet) {
      socket.emit('bet:error', 'No active bet');
      return;
    }
    bet.cashedOut = true;
    bet.cashOutMultiplier = crashMultiplier;
    const winAmount = bet.amount * bet.cashOutMultiplier;
    socket.emit('bet:cashedout', { multiplier: bet.cashOutMultiplier, winAmount });
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log('Server running on port', PORT);
  startRound();
});