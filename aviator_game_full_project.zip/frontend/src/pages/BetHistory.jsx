import { useEffect, useState } from 'react';
import API from '../api';

export default function BetHistory() {
  const [bets, setBets] = useState([]);

  useEffect(() => {
    API.get('/bets/history').then(res => setBets(res.data.bets));
  }, []);

  return (
    <div>
      <h1>Last 10 Bets</h1>
      <table>
        <thead>
          <tr>
            <th>Round</th>
            <th>Bet Amount</th>
            <th>Crash Multiplier</th>
            <th>Cash Out Multiplier</th>
            <th>Win Amount</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
          {bets.map(b => (
            <tr key={b._id}>
              <td>{b.round}</td>
              <td>₹{b.amount}</td>
              <td>{b.crashMultiplier}x</td>
              <td>{b.cashOutMultiplier ? b.cashOutMultiplier + 'x' : '-'}</td>
              <td>₹{b.winAmount.toFixed(2)}</td>
              <td>{new Date(b.createdAt).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <a href="/">Back</a>
    </div>
  );
}