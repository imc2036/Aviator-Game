import { useEffect, useState } from 'react';
import socket from '../socket';
import API from '../api';

export default function Dashboard() {
  const [balance, setBalance] = useState(0);
  const [betAmount, setBetAmount] = useState(10);
  const [round, setRound] = useState(0);
  const [crashMultiplier, setCrashMultiplier] = useState(0);
  const [message, setMessage] = useState('');

  useEffect(() => {
    socket.on('balance:update', data => setBalance(data.balance));
    socket.on('round:start', data => {
      setRound(data.round);
      setCrashMultiplier(0);
      setMessage('Place your bets!');
    });
    socket.on('round:end', data => {
      setCrashMultiplier(data.crashMultiplier);
      setMessage(`Round ended at ${data.crashMultiplier}x`);
    });
    socket.on('bet:confirmed', data => setMessage(`Bet placed: ₹${data.amount}`));
    socket.on('bet:cashedout', data => setMessage(`Cashed out at ${data.multiplier}x! Won ₹${data.winAmount.toFixed(2)}`));
    socket.on('bet:error', err => setMessage(`Error: ${err}`));
  }, []);

  function placeBet() {
    socket.emit('bet:place', { amount: Number(betAmount) });
  }

  function cashOut() {
    socket.emit('bet:cashout');
  }

  async function deposit() {
    const amount = prompt('Deposit amount');
    if (amount && Number(amount) > 0) {
      const res = await API.post('/wallet/deposit', { amount: Number(amount) });
      setBalance(res.data.balance);
    }
  }

  async function withdraw() {
    const amount = prompt('Withdraw amount');
    if (amount && Number(amount) > 0) {
      try {
        const res = await API.post('/wallet/withdraw', { amount: Number(amount) });
        setBalance(res.data.balance);
      } catch (e) {
        alert(e.response?.data?.message || 'Withdraw failed');
      }
    }
  }

  return (
    <div>
      <h1>Round: {round}</h1>
      <h2>Balance: ₹{balance.toFixed(2)}</h2>
      <h3>Crash Multiplier: {crashMultiplier}x</h3>
      <input type="number" value={betAmount} onChange={e => setBetAmount(e.target.value)} min="1" />
      <button onClick={placeBet}>Place Bet</button>
      <button onClick={cashOut}>Cash Out</button>
      <button onClick={deposit}>Deposit</button>
      <button onClick={withdraw}>Withdraw</button>
      <p>{message}</p>
      <a href="/history">View Bet History</a>
    </div>
  );
}