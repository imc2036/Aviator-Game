import { useState } from 'react';
import API from '../api';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState('login'); // or register
  const [error, setError] = useState('');

  async function submit() {
    try {
      const res = await API.post(`/auth/${mode}`, { email, password });
      localStorage.setItem('token', res.data.token);
      window.location.reload();
    } catch (e) {
      setError(e.response?.data?.message || 'Error');
    }
  }

  return (
    <div>
      <h1>{mode === 'login' ? 'Login' : 'Register'}</h1>
      <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
      <input placeholder="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
      <button onClick={submit}>{mode === 'login' ? 'Login' : 'Register'}</button>
      <button onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
        Switch to {mode === 'login' ? 'Register' : 'Login'}
      </button>
      {error && <p>{error}</p>}
    </div>
  );
}